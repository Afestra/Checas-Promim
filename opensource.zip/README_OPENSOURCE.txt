README — Limanta Checas Promim Open Source Demo
================================================

PACKAGE CONTENTS:
  LimantaChecasPromim-Demo.ttf    — Restricted uppercase-only demo font (1 Font only)
  OPEN_SOURCE_DEMO_WARNING.txt     — ⚠️ License & modification warning
  EULA_LICENSE_AGREEMENT.txt       — License agreement
  README_OPENSOURCE.txt            — This document

IMPORTANT:
  This font is intentionally restricted to uppercase display characters only
  and is not suitable for continuous body text reading.

  Editing or modifying this file voids all licenses.
  Commercial multi-weight family (Light, Semilight, Regular, Medium, SemiBold, Bold):
  https://arpitbharadwaj6.gumroad.com/l/limantapromim
